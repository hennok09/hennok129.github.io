package app.akexorcist.joystickcontroller;

import android.os.Bundle;
import android.app.Activity;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnTouchListener;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

public class Main extends Activity {
	RelativeLayout layout_joystick, layout_joystick2;
	ImageView image_joystick, image_border;
	TextView textView1, textView2, textView3, textView4, textView5;
	
	JoyStickClass js, js2;
	
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);

        textView1 = (TextView)findViewById(R.id.textView1);
        textView2 = (TextView)findViewById(R.id.textView2);
        
	    layout_joystick = (RelativeLayout)findViewById(R.id.layout_joystick);
		layout_joystick2 = (RelativeLayout)findViewById(R.id.layout_joystick2);

        js = new JoyStickClass(getApplicationContext()
        		, layout_joystick, R.drawable.image_button);

		js2 = new JoyStickClass(getApplicationContext()
				, layout_joystick2, R.drawable.image_button);

	    js.setStickSize(150, 150);
	    js.setLayoutSize(500, 500);
	    js.setLayoutAlpha(150);
	    js.setStickAlpha(100);
	    js.setOffset(90);
	    js.setMinimumDistance(50);
	    
	    layout_joystick.setOnTouchListener(new OnTouchListener() {
			public boolean onTouch(View arg0, MotionEvent arg1) {
				js.drawStick(arg1);
				if(arg1.getAction() == MotionEvent.ACTION_DOWN
						|| arg1.getAction() == MotionEvent.ACTION_MOVE) {
					textView1.setText("X : " + String.valueOf(js.getX()));
					textView2.setText("Y : " + String.valueOf(js.getY()));
				} else if(arg1.getAction() == MotionEvent.ACTION_UP) {
					textView1.setText("X :");
					textView2.setText("Y :");
				}
				return true;
			}
        });

		layout_joystick2.setOnTouchListener(new OnTouchListener() {
			public boolean onTouch(View arg0, MotionEvent arg1) {
				js.drawStick(arg1);
				if(arg1.getAction() == MotionEvent.ACTION_DOWN
						|| arg1.getAction() == MotionEvent.ACTION_MOVE) {
					textView1.setText("X : " + String.valueOf(js.getX()));
					textView2.setText("Y : " + String.valueOf(js.getY()));
				} else if(arg1.getAction() == MotionEvent.ACTION_UP) {
					textView1.setText("X :");
					textView2.setText("Y :");
				}
				return true;
			}
		});

    } 	
}
